export class Employee {
    id: number;
    firstName: string;
    lastName: string;
    emailId: string;
    dov: Date;
    reason: string;
    doctor: string;
}
